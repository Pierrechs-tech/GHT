
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<script src="//code.jquery.com/jquery.js"></script>

<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">

<!-- Pour que les tablettes et smartphone adapte la page à la résolution -->
<meta name="viewport" content="width=device-width; initial-scale=1; maximum-scale=1">
<meta name="viewport" content="height=device-height; initial-scale=1; maximum-scale=1">


<!-- JQuery -->
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js" integrity="sha256-T0Vest3yCU7pafRw9r+settMBX6JkKN06dqBnpQ8d30=" crossorigin="anonymous"></script>

<!-- APPEL VERS LES LIBRAIRIE JS JQUERY ET DATATABLE  -->
<script type="text/javascript" language="javascript" src="/Scripts/jqueryUI/jquery.dataTables.js"></script>
<!-- APPEL DES CSS MODIFIABLE EN FONCTION DE LA CHARTE GRAPHIQUE -->
<link href="/Style/jqueryUI/jquery-ui.css" rel="stylesheet" />
<link rel="stylesheet" type="text/css" href="/Style/jqueryUI/jquery.dataTables.css" />

<!-- Bootstrap -->
<link rel="stylesheet" href="/Style/bootstrap/bootstrap.min.css" type="text/css" />
<link rel="stylesheet" href="/Style/bootstrap/bootamc.css" type="text/css" />
<script type="text/javascript" src="/Scripts/bootstrap/bootstrap.min.js"></script>
<script type="text/javascript" src="/Scripts/bootstrap/transition.js"></script>
<script type="text/javascript" src="/Scripts/bootstrap/collapse.js"></script>


<!-- ekko-lightbox -->
<link href="/Style/bootstrap/ekko-lightbox.min.css" rel="stylesheet">
<script src="/Scripts/bootstrap/ekko-lightbox.min.js"></script>

<!-- Responsive slider -->
<script src="/Scripts/ResponsiveSlider/responsiveslides.js"></script>


<!--[if lt IE 9]>
    <script type="text/javascript" src="//Scripts/respond.min.js"></script>
    <script type="text/javascript" src="//Scripts/css3-mediaqueries.js"></script>
    <script type="text/javascript" src="//Scripts/css-media-query-ie.min.js"></script>
    <script type="text/javascript" src="//Scripts/css-media-query-ie.js"></script>
    <![endif]-->

<link href="https://fonts.googleapis.com/css?family=Montserrat:400,500,600,700|Open+Sans:400,400i,700,700i" rel="stylesheet">

<link rel="stylesheet" href="/Style/FontAwesome/css/all.min.css" type="text/css" />




<style type="text/css">
    html {
        font-size: 16px;
    }

    body {
        font-family: Arial;
    }

    /*Visibilité des div*/

    .Cache {
        display: none;
    }

    .Visible {
        display: block;
    }

    .ScrollDiv {
        width: auto;
    }
	
	
	/* Recherche Google */
	.gsc-control-cse
	{
		padding:0;
	}
	
	.gsc-search-button
	{
		background-color: #60a9dd;
		border-radius: 5px;

	}
	
</style>
<script type="text/javascript">
    function CallPrint() {
        var prtContent = document.getElementById('contenu');
        var WinPrint = window.open('', '', 'letf=0,top=0,width=710,height=600,toolbar=0,scrollbars=1,status=0');

        WinPrint.document.write('<style type="text/css">html{font-size: 16px;}</style><link rel="stylesheet" type="text/css" href="/Style/Style.css"><link rel="stylesheet" type="text/css" href="/Style/StyleCK.css"><body>' + prtContent.innerHTML + '</body>');
        WinPrint.document.close();
        WinPrint.focus();
        WinPrint.print();
    }


    function PortailOver(PortailID) {
        window.document.getElementById("CadreModule" + PortailID).className = "Visible";		 
		/*if(PortailID == "8")
		{
			window.document.getElementById("ctl00_PanContentPlaceHolder1").style.display = "none";
			window.document.getElementById("ctl00_PanOffresdeSoins").style.display = "block";
			window.document.getElementById("ctl00_PanEnteteListe").style.display = "none";
			
		}
		*/	
    }

    function PortailOut(PortailID) {
        window.document.getElementById("CadreModule" + PortailID).className = "Cache";				 
		/*if(PortailID != "8")
		{
			window.document.getElementById("ctl00_PanContentPlaceHolder1").style.display = "block";
			window.document.getElementById("ctl00_PanOffresdeSoins").style.display = "none";
			window.document.getElementById("ctl00_PanEnteteListe").style.display = "block";
		}*/
    }

    function AfficheCacheDiv(Div) {
        if (window.document.getElementById(Div).className == "Cache") {
            window.document.getElementById(Div).className = "Visible";
        }
        else {
            window.document.getElementById(Div).className = "Cache";
        }
    }

    function AfficheDivOver(Div) {
        window.document.getElementById(Div).className = "Visible";
    }

    function CacheDivOver(Div) {
        window.document.getElementById(Div).className = "Cache";
    }

    function AfficheSousModule(Cible) {
        window.document.getElementById("CadreSousModule_" + Cible).style.display = "block";
    }

    function CacheSousModule(Cible) {
        window.document.getElementById("CadreSousModule_" + Cible).style.display = "none";
    }

    function AfficheDiv(Div) {
        window.document.getElementById(Div).style.display = "block";
    }

    function CacheDiv(Div) {
        window.document.getElementById(Div).style.display = "none";
    }
	
	
    $(function () {	
		
		
        
		// window load
		$( document ).ready(function() {
            // ouverture du 1er item par défaut dans le portail Patient et Entourage
            //$('.Portail2 .panel-group a:first').trigger("click");
		});

		
		/* scroll si entete plus haut que haut de la fenêtre */
        $('.panel-collapse').on('shown.bs.collapse', function (e) {
		
			var $panel = $(this),			 
			$window    = $(window),
			offset     = $panel.offset();
						
			if ($(this).is(e.target)) 
			{
				if($window.scrollTop() > offset.top)
				{			
					$('html,body').animate({
						scrollTop: $panel.parent().offset().top
					}, 500);
				}
			}
        });
    });
</script>




<head id="ctl00_Head1"><title>
	
        GHT de Sarreguemines 
</title>
    <!-- styles minimum pour les nouveaux site créés -->
    <!--<link rel="stylesheet" type="text/css" href="Style/default.css" />-->

    <!-- styles bootstrap  -->
    <link rel="stylesheet" type="text/css" href="/Style/Style.css" /><link rel="stylesheet" type="text/css" href="/Style/bootstrap/bootamc.css" />

    <!-- styles presonnalisé du site -->
    <link rel="stylesheet" type="text/css" href="/Style/Master.css" /><link rel="stylesheet" type="text/css" href="/Ght_sarreguemines.css" /><link rel="stylesheet" type="text/css" href="/Style/StyleCK.css" /><link rel="stylesheet" type="text/css" href="/Style/Slideshow.css" />
    <link rel="stylesheet" href="/Style/Accueil.css" />

</head>
<body>
    <form name="aspnetForm" method="post" action="/MicrosoftAjaxSerialization.js" id="aspnetForm">
<div>
<input type="hidden" name="ctl00_ToolkitScriptManager1_HiddenField" id="ctl00_ToolkitScriptManager1_HiddenField" value="" />
<input type="hidden" name="__EVENTTARGET" id="__EVENTTARGET" value="" />
<input type="hidden" name="__EVENTARGUMENT" id="__EVENTARGUMENT" value="" />
<input type="hidden" name="__VIEWSTATE" id="__VIEWSTATE" value="/wEPDwUKMTAwNDE0ODgzNg9kFgJmDw8WCh4LVGl0cmVQYWdldnMFFUdIVCBkZSBTYXJyZWd1ZW1pbmVzIB4KTGFuZ3VlSUR2cwIBHgtQb3J0YWlsSUR2cwL/////Dx4KTW9kdWxlSUR2cwL/////Dx4NSW1hZ2VDZW50cmV2cwUzL0ltYWdlcy9BY2N1ZWlsL1NsaWRlc2hvdy9iYW5kZWF1X3NhcnJlZ3VlbWluZXMuanBnZBYCAgEPFgIeBmFjdGlvbgUeL01pY3Jvc29mdEFqYXhTZXJpYWxpemF0aW9uLmpzFiQCAg8PFgQeC05hdmlnYXRlVXJsBQ9+L3VyZ2VuY2VzLzIvNjQeBFRleHQFCFVyZ2VuY2VzZGQCAw8PFgIfBgUbfi9SZW5kZXotdm91cy1lbi1saWduZS8yLzMwZGQCBA8WAh4LXyFJdGVtQ291bnQCAxYGZg9kFghmDxUEATgBOAE4C1BvcnRhaWxMaWVuZAIBDw8WAh8GBRV+L09mZnJlLWRlLXNvaW5zLzIvNjhkFgJmDxUBDk9mZnJlIGRlIHNvaW5zZAIEDxUCATgFQ2FjaGVkAgUPFgIfCGZkAgEPZBYIZg8VBAEyATIBMgtQb3J0YWlsTGllbmQCAQ9kFgJmDxUBFFBhdGllbnQgZXQgZW50b3VyYWdlZAIEDxUCATIFQ2FjaGVkAgUPFgIfCAIFFgpmD2QWCGYPFQMLQ2FkcmVNb2R1bGUCNzUCNzVkAgMPDxYGHgZUYXJnZXRlHwcFDENvbnN1bHRhdGlvbh8GBRMvQ29uc3VsdGF0aW9ucy8zLzc1ZGQCBA8VAQI3NWQCBQ8WAh8IZmQCAQ9kFghmDxUDC0NhZHJlTW9kdWxlAjU3AjU3ZAIDDw8WBh8JZR8HBQ9Ib3NwaXRhbGlzYXRpb24fBgUVL0hvc3BpdGFsaXNhdGlvbi8zLzU3ZGQCBA8VAQI1N2QCBQ8WAh8IZmQCAg9kFghmDxUDC0NhZHJlTW9kdWxlAjc3Ajc3ZAIDDw8WBh8JZR8HBRpSZW5kcmUgdmlzaXRlIMOgIHVuIHByb2NoZR8GBRcvVmlzaXRlci11bi1wcm9jaGUvMy83N2RkAgQPFQECNzdkAgUPFgIfCGZkAgMPZBYIZg8VAwtDYWRyZU1vZHVsZQIzNwIzN2QCAw8PFgYfCWUfBwUOUkVHTEVNRU5UQVRJT04fBgUVL3LDqGdsZW1lbnRhdGlvbi8yLzM3ZGQCBA8VAQIzN2QCBQ8WAh8IZmQCBA9kFghmDxUDC0NhZHJlTW9kdWxlAjM4AjM4ZAIDDw8WBh8JZR8HBQxTYXRpc2ZhY3Rpb24fBgUSL1NhdGlzZmFjdGlvbi8zLzM4ZGQCBA8VAQIzOGQCBQ8WAh8IZmQCAg9kFghmDxUEATcBNwE3C1BvcnRhaWxMaWVuZAIBD2QWAmYPFQEOUHJvZmVzc2lvbm5lbHNkAgQPFQIBNwVDYWNoZWQCBQ8WAh8IAgYWDGYPZBYIZg8VAwtDYWRyZU1vZHVsZQI4OQI4OWQCAw8PFgYfCWUfBwUPQ29taXTDqSBFdGhpcXVlHwYFFC9jb21pdGUtZXRoaXF1ZS8yLzg5ZGQCBA8VAQI4OWQCBQ8WAh8IZmQCAQ9kFghmDxUDC0NhZHJlTW9kdWxlAjk1Ajk1ZAIDDw8WBh8JZR8HBSZQw6lwaW5pw6hyZSBkJ2VudHJlcHJpc2UgRS1zYW50w6kgQ0NETB8GBSkvcGVwaW5pZXJlLWQtZW50cmVwcmlzZS1lLXNhbnRlLWNjZGwvMy85NWRkAgQPFQECOTVkAgUPFgIfCGZkAgIPZBYIZg8VAwtDYWRyZU1vZHVsZQIzMQIzMWQCAw8PFgYfCWUfBwUYUHJvZmVzc2lvbm5lbHMgZGUgc2FudMOpHwYFHS9Qcm9mZXNzaW9ubmVscy1kZS1zYW50ZS8zLzMxZGQCBA8VAQIzMWQCBQ8WAh8IZmQCAw9kFghmDxUDC0NhZHJlTW9kdWxlAjMyAjMyZAIDDw8WBh8JZR8HBQ9PZmZyZXMgZCdlbXBsb2kfBgUML0VtcGxvaS83LzMyZGQCBA8VAQIzMmQCBQ8WAh8IZmQCBA9kFghmDxUDC0NhZHJlTW9kdWxlAjg4Ajg4ZAIDDw8WBh8JZR8HBSxTaWduYWxlbWVudCBkZXMgdmlvbGVuY2VzIGV0IGR1IGhhcmPDqGxlbWVudB8GBTEvc2lnbmFsZW1lbnQtZGVzLXZpb2xlbmNlcy1ldC1kdS1oYXJjZWxlbWVudC8yLzg4ZGQCBA8VAQI4OGQCBQ8WAh8IZmQCBQ9kFghmDxUDC0NhZHJlTW9kdWxlAjM0AjM0ZAIDDw8WBh8JZR8HBRRBY2hhdHMsIGZvdXJuaXNzZXVycx8GBRIvRm91cm5pc3NldXJzLzMvMzRkZAIEDxUBAjM0ZAIFDxYCHwhmZAIFDxYCHwgCAxYGZg9kFgZmDxUCDlNQX0ZvbmRQb3J0YWlsFC9PZmZyZS1kZS1zb2lucy8yLzY4ZAIBDw8WBB8HBQ5PRkZSRSBERSBTT0lOUx4PQ29tbWFuZEFyZ3VtZW50BQE4ZGQCAw8WAh8IZmQCAQ9kFgZmDxUCDlNQX0ZvbmRQb3J0YWlsGS9QcmVuZHJlLXJlbmRlei12b3VzLzMvNzRkAgEPDxYEHwcFFFBBVElFTlQgRVQgRU5UT1VSQUdFHwoFATJkZAIDDxYCHwgCBRYKZg9kFghmDxUBEy9Db25zdWx0YXRpb25zLzMvNzVkAgEPDxYEHwcFDENvbnN1bHRhdGlvbh8KBQI3NWRkAgIPFQEVc3R5bGU9J2Rpc3BsYXk6bm9uZTsnZAIDDxYCHwhmZAIBD2QWCGYPFQEVL0hvc3BpdGFsaXNhdGlvbi8zLzU3ZAIBDw8WBB8HBQ9Ib3NwaXRhbGlzYXRpb24fCgUCNTdkZAICDxUBFXN0eWxlPSdkaXNwbGF5Om5vbmU7J2QCAw8WAh8IZmQCAg9kFghmDxUBFy9WaXNpdGVyLXVuLXByb2NoZS8zLzc3ZAIBDw8WBB8HBRpSZW5kcmUgdmlzaXRlIMOgIHVuIHByb2NoZR8KBQI3N2RkAgIPFQEVc3R5bGU9J2Rpc3BsYXk6bm9uZTsnZAIDDxYCHwhmZAIDD2QWCGYPFQEVL3LDqGdsZW1lbnRhdGlvbi8yLzM3ZAIBDw8WBB8HBQ5SRUdMRU1FTlRBVElPTh8KBQIzN2RkAgIPFQEVc3R5bGU9J2Rpc3BsYXk6bm9uZTsnZAIDDxYCHwhmZAIED2QWCGYPFQESL1NhdGlzZmFjdGlvbi8zLzM4ZAIBDw8WBB8HBQxTYXRpc2ZhY3Rpb24fCgUCMzhkZAICDxUBFXN0eWxlPSdkaXNwbGF5Om5vbmU7J2QCAw8WAh8IZmQCAg9kFgZmDxUCDlNQX0ZvbmRQb3J0YWlsHS9Qcm9mZXNzaW9ubmVscy1kZS1zYW50ZS8zLzMxZAIBDw8WBB8HBQ5QUk9GRVNTSU9OTkVMUx8KBQE3ZGQCAw8WAh8IAgYWDGYPZBYIZg8VARQvY29taXRlLWV0aGlxdWUvMi84OWQCAQ8PFgQfBwUPQ29taXTDqSBFdGhpcXVlHwoFAjg5ZGQCAg8VARVzdHlsZT0nZGlzcGxheTpub25lOydkAgMPFgIfCGZkAgEPZBYIZg8VASkvcGVwaW5pZXJlLWQtZW50cmVwcmlzZS1lLXNhbnRlLWNjZGwvMy85NWQCAQ8PFgQfBwUmUMOpcGluacOocmUgZCdlbnRyZXByaXNlIEUtc2FudMOpIENDREwfCgUCOTVkZAICDxUBFXN0eWxlPSdkaXNwbGF5Om5vbmU7J2QCAw8WAh8IZmQCAg9kFghmDxUBHS9Qcm9mZXNzaW9ubmVscy1kZS1zYW50ZS8zLzMxZAIBDw8WBB8HBRhQcm9mZXNzaW9ubmVscyBkZSBzYW50w6kfCgUBMWRkAgIPFQEVc3R5bGU9J2Rpc3BsYXk6bm9uZTsnZAIDDxYCHwhmZAIDD2QWCGYPFQEML0VtcGxvaS83LzMyZAIBDw8WBB8HBQ9PZmZyZXMgZCdlbXBsb2kfCgUCMzJkZAICDxUBFXN0eWxlPSdkaXNwbGF5Om5vbmU7J2QCAw8WAh8IZmQCBA9kFghmDxUBMS9zaWduYWxlbWVudC1kZXMtdmlvbGVuY2VzLWV0LWR1LWhhcmNlbGVtZW50LzIvODhkAgEPDxYEHwcFLFNpZ25hbGVtZW50IGRlcyB2aW9sZW5jZXMgZXQgZHUgaGFyY8OobGVtZW50HwoFAjg4ZGQCAg8VARVzdHlsZT0nZGlzcGxheTpub25lOydkAgMPFgIfCGZkAgUPZBYIZg8VARIvRm91cm5pc3NldXJzLzMvMzRkAgEPDxYEHwcFFEFjaGF0cywgZm91cm5pc3NldXJzHwoFAjM0ZGQCAg8VARVzdHlsZT0nZGlzcGxheTpub25lOydkAgMPFgIfCGZkAgYPDxYCHghJbWFnZVVybAUaL2ltYWdlcy9EZWZhdWx0L0FNb2lucy5wbmdkZAIHDw8WAh8LBRUvaW1hZ2VzL0RlZmF1bHQvQS5wbmdkZAIIDw8WAh8LBRkvaW1hZ2VzL0RlZmF1bHQvQVBsdXMucG5nZGQCCg8PFgIeB1Zpc2libGVoZGQCCw8PFgIfDGhkZAIMD2QWBGYPDxYCHwYFFS9vZmZyZXMtZGUtc29pbnMvNS82NWRkAgEPDxYCHwYFES9PZmZyZS1zb2lucy81LzU1ZGQCDQ8PFgIfDGdkFgICAw9kFgoCAQ8WAh8IAgMWBmYPZBYCZg8VAhJMaW5rVG9EQi5TTEkuSW1hZ2U0L1Jlc3NvdXJjZXMvU0xJL0NIUyBKVUlMTEVUIDIwMjEyMDIzMTAzMTE1MzMzMjA1LmpwZ2QCAQ9kFgJmDxUCEkxpbmtUb0RCLlNMSS5JbWFnZS8vUmVzc291cmNlcy9TTEkvQ0ggTUFJIDIwMTkyMDIzMTAzMTE1MzM0MzM0LmpwZ2QCAg9kFgJmDxUCEkxpbmtUb0RCLlNMSS5JbWFnZTcvUmVzc291cmNlcy9TTEkvQklUQ0hFIEpVSUxMRVQgMjAyMTIwMjMxMDMxMTUzMzU0NDcuanBnZAIDDxYCHwgCBBYIZg9kFgICAQ8PFgIfBgUTfi9QcmVzZW50YXRpb24vMi82MGQWAgIBDw8WAh8HBQNDSFNkZAIBD2QWAgIBDw8WAh8GBRB+L0RpcmVjdGlvbi8yLzYxZBYCAgEPDxYCHwcFAkNIZGQCAg9kFgICAQ8PFgIfBgUTfi9wcmVzZW50YXRpb24vMi82MmQWAgIBDw8WAh8HBRJHSFQgZGUgTW9zZWxsZS1Fc3RkZAIDD2QWAgIBDw8WAh8GBRN+L3ByZXNlbnRhdGlvbi8yLzYzZBYCAgEPDxYCHwcFBElGU0lkZAIFDxYCHwgCBBYIZg9kFgRmDxUBFy9pbWFnZXMvYWNjdWVpbC9SRFYuanBnZAIBDw8WAh8GBRt+L1JlbmRlei12b3VzLWVuLWxpZ25lLzIvMzBkFgICAQ8PFgIfBwUWUHJlbmRyZSB1biByZW5kZXotdm91c2RkAgEPZBYEZg8VAS0vaW1hZ2VzL2FjY3VlaWwvZnJhaXNfc2FudGVfc2FycmVndWVtaW5lcy5wbmdkAgEPDxYCHwYFE34vUmVnbGVyLXNvaW5zLzIvMjRkFgICAQ8PFgIfBwUZUGF5ZXIgbGVzIGZyYWlzIGRlIHNhbnTDqWRkAgIPZBYEZg8VARkvaW1hZ2VzL2FjY3VlaWwvcmFkaW8uanBnZAIBDw8WBB8GBStodHRwczovL2ltYWdlcmllLmhvcGl0YXV4LXNhcnJlZ3VlbWluZXMuZnIvHwkFBl9ibGFua2QWAgIBDw8WAh8HBSJSw6lzdWx0YXRzIGQnZXhhbWVucyByYWRpb2xvZ2lxdWVzZGQCAw9kFgRmDxUBIy9pbWFnZXMvYWNjdWVpbC9kb3NzaWVyX21lZGljYWwuanBnZAIBDw8WAh8GBR5+L0RlbWFuZGUtZG9zc2llci1tZWRpY2FsLzIvMjNkFgICAQ8PFgIfBwUbRGVtYW5kZSBkZSBkb3NzaWVyIG3DqWRpY2FsZGQCBw8WAh8IAgMWBmYPZBYCAgEPDxYCHwYFNn4vcG9ydGVzLW91dmVydGVzLW5vdXZlbC1pZnNpLWRlLXNhcnJlZ3VlbWluZXMvMS8xLzExOGQWCAIDDw8WAh8LBUQvUmVzc291cmNlcy9ORVcvQUNUVSAtUE8gSUZTSSAxNyBNQUkgMjUtMDEtMDEtMDEyMDI1MDUxMjA3MzY1NzUwLnBuZ2RkAgUPDxYCHwcFDCAxMiBtYWkgMjAyNWRkAgYPDxYCHwcFLFBPUlRFUyBPVVZFUlRFUyBOT1VWRUwgSUZTSSBERSBTQVJSRUdVRU1JTkVTZGQCCQ8VAQBkAgEPZBYCAgEPDxYCHwYFJX4vam91cm5lZS1wb3J0ZXMtb3V2ZXJ0ZXMtaGFkLzEvMS8xMTdkFggCAw8PFgIfCwVCL1Jlc3NvdXJjZXMvTkVXL0FDVFUgLSBTT0lSRUUgUE8gSEFEIDIzMDUyNS0wMTIwMjUwNTEzMDk0NDAyNjQucG5nZGQCBQ8PFgIfBwUOIDI4IGF2cmlsIDIwMjVkZAIGDw8WAh8HBRtKT1VSTkVFIFBPUlRFUyBPVVZFUlRFUyBIQURkZAIJDxUBJzxkaXYgY2xhc3M9J2NsZWFyZml4IHZpc2libGUtc20nPjwvZGl2PmQCAg9kFgICAQ8PFgIfBgUnfi9pbmRleC1lZ2FsaXRlLXByb2Zlc3Npb25uZWxsZS8xLzEvMTEyZBYIAgMPDxYCHwsFOS9SZXNzb3VyY2VzL05FVy9JTkRFWCBFR0FMSVRFIFBST0YtMDEyMDI0MTIwNTE1MjIyMDc3LnBuZ2RkAgUPDxYCHwcFESA1IGTDqWNlbWJyZSAyMDI0ZGQCBg8PFgIfBwUfSW5kZXggw6lnYWxpdMOpIHByb2Zlc3Npb25uZWxsZWRkAgkPFQEAZAIJDxYCHwgCBBYIZg9kFgICAQ8PFgIfBgUlfi9kb24tZC1vcmdhbmVzLWV0LWRlLXRpc3N1cy8xLzY5LzExOWQWCmYPFQEEQmxldWQCAw8PFgIfCwU7L1Jlc3NvdXJjZXMvTkVXL0ZPQ1VTIC0gIERPTiBPUkdBTkVTLTAxMjAyNTA2MTExMTU3MTQzNy5wbmdkZAIFDw8WAh8HBQ0gMTEganVpbiAyMDI1ZGQCBg8PFgIfBwUaRE9OIEQnT1JHQU5FUyBFVCBERSBUSVNTVVNkZAIJDxUBAGQCAQ9kFgICAQ8PFgIfBgUUfi9tYXJzLWJsZXUvMS82OS8xMTVkFgpmDxUBBEdyaXNkAgMPDxYCHwsFOS9SZXNzb3VyY2VzL05FVy9GT0NVUyAtICBNQVJTIEJMRVUtMDEyMDI1MDMwNjE0MDQzNDQ2LnBuZ2RkAgUPDxYCHwcFDCA2IG1hcnMgMjAyNWRkAgYPDxYCHwcFCU1BUlMgQkxFVWRkAgkPFQEnPGRpdiBjbGFzcz0nY2xlYXJmaXggdmlzaWJsZS1zbSc+PC9kaXY+ZAICD2QWAgIBDw8WAh8GBSl+L1JvYm90LWQtYXNzaXN0YW5jZS1jaGlydXJnaWNhbC8xLzY5LzEwOWQWCmYPFQEEQmxldWQCAw8PFgIfCwU2L1Jlc3NvdXJjZXMvTkVXL0FDVFUgLSByb2JvdC0wMS0wMTIwMjQwOTIzMTA0MDMyMTUucG5nZGQCBQ8PFgIfBwUSIDIzIHNlcHRlbWJyZSAyMDI0ZGQCBg8PFgIfBwUeUm9ib3QgZCdhc3Npc3RhbmNlIGNoaXJ1cmdpY2FsZGQCCQ8VAQBkAgMPZBYCAgEPDxYCHwYFEn4vdXJnZW5jZXMvMS82OS85M2QWCmYPFQEER3Jpc2QCAw8PFgIfCwU1L1Jlc3NvdXJjZXMvTkVXL0ZPQ1VTIFVSR0VOQ0VTLTAxMjAyNDAyMjMxMDQzMTQ3MS5wbmdkZAIFDw8WAh8HBREgMjMgZsOpdnJpZXIgMjAyNGRkAgYPDxYCHwcFCFVyZ2VuY2VzZGQCCQ8VASc8ZGl2IGNsYXNzPSdjbGVhcmZpeCB2aXNpYmxlLXNtJz48L2Rpdj5kAg8PDxYEHwcFDEZBSVJFIFVOIERPTh8GBQl+L0RPTi8yLzZkZAIQDw8WBB8HBQ5Ob3VzIGNvbnRhY3Rlch8GBQ5+L0NvbnRhY3QvMTAvN2RkAhEPDxYEHwcFDUNvbW11bmljYXRpb24fBgUQfi9hY3R1YWxpdGVzLzEvMWRkAhIPDxYEHwcFDFBsYW4gZHUgc2l0ZR8GBRF+L1BsYW4tc2l0ZS8xNi8xN2RkAhMPDxYEHwcFEU1lbnRpb25zIGzDqWdhbGVzHwYFF34vTWVudGlvbnMtbGVnYWxlcy8yLzE4ZGQCFA8PFgIfDGhkZAIVD2QWAgIFDw8WAh8GBR4vTWVudGlvbnMtbGVnYWxlcy8yLzE4I0Nvb2tpZXNkZBgBBR5fX0NvbnRyb2xzUmVxdWlyZVBvc3RCYWNrS2V5X18WAwUOY3RsMDAkSUJBTW9pbnMFCWN0bDAwJElCQQUNY3RsMDAkSUJBUGx1cyH98NaZHmbMapXlZLhHeFFvVomktm2TmSMS/rmdmpJw" />
</div>

<script type="text/javascript">
//<![CDATA[
var theForm = document.forms['aspnetForm'];
if (!theForm) {
    theForm = document.aspnetForm;
}
function __doPostBack(eventTarget, eventArgument) {
    if (!theForm.onsubmit || (theForm.onsubmit() != false)) {
        theForm.__EVENTTARGET.value = eventTarget;
        theForm.__EVENTARGUMENT.value = eventArgument;
        theForm.submit();
    }
}
//]]>
</script>


<script src="/WebResource.axd?d=9cAV11wUu06OHi1K-AW_fgHb9FE3w-PlHtUoWuRge30U5iZwftlCl_Y-jF3AHUms7KQjcp9fln6bGf9LO_6G1sStd0V93XWHzGmeXY-DtvA1&amp;t=637110284437816177" type="text/javascript"></script>


<script type="text/javascript">
//<![CDATA[
var __cultureInfo = {"name":"fr-FR","numberFormat":{"CurrencyDecimalDigits":2,"CurrencyDecimalSeparator":",","IsReadOnly":true,"CurrencyGroupSizes":[3],"NumberGroupSizes":[3],"PercentGroupSizes":[3],"CurrencyGroupSeparator":" ","CurrencySymbol":"€","NaNSymbol":"Non numérique","CurrencyNegativePattern":8,"NumberNegativePattern":1,"PercentPositivePattern":0,"PercentNegativePattern":0,"NegativeInfinitySymbol":"-Infini","NegativeSign":"-","NumberDecimalDigits":2,"NumberDecimalSeparator":",","NumberGroupSeparator":" ","CurrencyPositivePattern":3,"PositiveInfinitySymbol":"+Infini","PositiveSign":"+","PercentDecimalDigits":2,"PercentDecimalSeparator":",","PercentGroupSeparator":" ","PercentSymbol":"%","PerMilleSymbol":"‰","NativeDigits":["0","1","2","3","4","5","6","7","8","9"],"DigitSubstitution":1},"dateTimeFormat":{"AMDesignator":"","Calendar":{"MinSupportedDateTime":"\/Date(-62135596800000)\/","MaxSupportedDateTime":"\/Date(253402297199999)\/","AlgorithmType":1,"CalendarType":1,"Eras":[1],"TwoDigitYearMax":2029,"IsReadOnly":true},"DateSeparator":"/","FirstDayOfWeek":1,"CalendarWeekRule":0,"FullDateTimePattern":"dddd d MMMM yyyy HH:mm:ss","LongDatePattern":"dddd d MMMM yyyy","LongTimePattern":"HH:mm:ss","MonthDayPattern":"d MMMM","PMDesignator":"","RFC1123Pattern":"ddd, dd MMM yyyy HH\u0027:\u0027mm\u0027:\u0027ss \u0027GMT\u0027","ShortDatePattern":"dd/MM/yyyy","ShortTimePattern":"HH:mm","SortableDateTimePattern":"yyyy\u0027-\u0027MM\u0027-\u0027dd\u0027T\u0027HH\u0027:\u0027mm\u0027:\u0027ss","TimeSeparator":":","UniversalSortableDateTimePattern":"yyyy\u0027-\u0027MM\u0027-\u0027dd HH\u0027:\u0027mm\u0027:\u0027ss\u0027Z\u0027","YearMonthPattern":"MMMM yyyy","AbbreviatedDayNames":["dim.","lun.","mar.","mer.","jeu.","ven.","sam."],"ShortestDayNames":["di","lu","ma","me","je","ve","sa"],"DayNames":["dimanche","lundi","mardi","mercredi","jeudi","vendredi","samedi"],"AbbreviatedMonthNames":["janv.","févr.","mars","avr.","mai","juin","juil.","août","sept.","oct.","nov.","déc.",""],"MonthNames":["janvier","février","mars","avril","mai","juin","juillet","août","septembre","octobre","novembre","décembre",""],"IsReadOnly":true,"NativeCalendarName":"calendrier grégorien","AbbreviatedMonthGenitiveNames":["janv.","févr.","mars","avr.","mai","juin","juil.","août","sept.","oct.","nov.","déc.",""],"MonthGenitiveNames":["janvier","février","mars","avril","mai","juin","juillet","août","septembre","octobre","novembre","décembre",""]},"eras":[1,"ap. J.-C.",null,0]};//]]>
</script>

<script src="/ScriptResource.axd?d=1z6J2j_mXp0nz1DoNxCyWxVp49prDP0hzhZK9tQDNhJ_XtntM5ofbpOPl_y4WSnJkz8xuxKGfSCwm2F-VJnyZ8N0tqQFzdBhm0fIoIN6Ypiypp5GuohBou6dCmKYfLKKTBc9_ptYV__IyJeUUHZfNg2&amp;t=ffffffffe3663df5" type="text/javascript"></script>
<script type="text/javascript">
//<![CDATA[
if (typeof(Sys) === 'undefined') throw new Error('ASP.NET Ajax client-side framework failed to load.');
//]]>
</script>

<script src="/ScriptResource.axd?d=lj-HLEmHQXhTPi-OLl3kMfyVl30vq80wr-Ps19Zw_TYZ3X3hzJjfcBNa_Lkm0nWT2oE8qw3Jcv_XEx2FLZfiwaCvoFOlKGOdAmOZJRZH1HPV6wUN181YrwnlWnviB7jw-nEw-DAkw50FHcLmfdheHQ2&amp;t=ffffffffe3663df5" type="text/javascript"></script>
<div>

	<input type="hidden" name="__VIEWSTATEGENERATOR" id="__VIEWSTATEGENERATOR" value="B2418DDA" />
	<input type="hidden" name="__SCROLLPOSITIONX" id="__SCROLLPOSITIONX" value="0" />
	<input type="hidden" name="__SCROLLPOSITIONY" id="__SCROLLPOSITIONY" value="0" />
	<input type="hidden" name="__EVENTVALIDATION" id="__EVENTVALIDATION" value="/wEdADOa3GE6VbiQ2aGY0ZEpgpYmP1d30CdA/K+RbFANGac6SHS5DlgAGHjTW68QgQ8yQ/7Io453NsjPVbV8aOKW+jle6ffEg66icLvGqkvjALpN6jLueDF8GIrHZhJQzmzxYYaWIJnTfhvfwo9ztxUJcHbxK5xLJM5p3J6Z/qky8jQyIlJ6A9WNGWcXDY3+HeuxaYppsq5V7tk9D5V0Z+RiAFLysWKW7miXAmVQUvTxzCNDDnZgAK6f4tszm56dXCac3+7H3P2PX4vl/0IkeGGByu2bH4uL6PhInH5YQBc3Z8bQD75r5hzkOYoXPnJoIr4XwUOUgC/7pHRRYpQClGpBqaSzKehgVc6G1t6bb1j2Y0+BcLTTscBSjh6nMOVR3YKry269RqfYxd/A9eeCFTVVlxOgdqfkZZYER0iVO8FSA0jO1Sg+YKrMLzef8Cpjh9ueiCogestBg5Qi9cLDGt1m71yxUJw+G73SWltj7m4Cuju9NbmM91W/fQ11ESMENyv2cruofQ7gliA0u3jRlfxm/QMvyur4tZ0R3KvNUf+y9i9BmewcIu3xvvwUe5F3ZrIZ3FuOXi8spkW8cMnoLBzNKuiIMsAw9vDbAa4hmZefAzQeQaqf5TFdILagNgnwCwZiOw9azGL9CcqmkTVVdZ9M6ZX3xq4VXjRPFw23fz5DBTHCWT04IpDlnhurthRJ05snui8i9HEovXJeKdzI5XclDDHH6M7p201HiJJprW5ox+f46P5Vsd/oDoD0sXqFIPxw9atCMtXJzkNu0qYE6dBKbIKLmLg42+BZpULZDm9VTQXEb0TdDvQ1UGgmhi0oC8fNvcfh6NFPZhXtca52DZV9Ftf5e1FSHJbHch4a6Z8i9T1nEzjUwlxtLHAL66GefRnAUrZbV+x85rnDP8ryo+6dklRkNtn5wAKQlRbwmJQuZD1DldwyAdhhucRGmeDw/eixmoUxXbmvH7ooewUJoKG+i6ZZ4JRKrP6VAwYJIP5QGhu97mTuW6kuwZ7p51M7K8jaHyD4gKIjrIgBtApxR6c0WxG9SFIdUPi+4d1kn5JyG7zd2Obd5knjk7ELyGVyvfHDJIW73gqybEewL2AsoaJUSYKfA50UROylrQw0CJ3/3ZAFZw==" />
</div>	
		<script type="text/javascript">
//<![CDATA[
Sys.WebForms.PageRequestManager._initialize('ctl00$ToolkitScriptManager1', 'aspnetForm', [], [], [], 90, 'ctl00');
//]]>
</script>

        <div id="Page" class="PageAccueil">
            <div id="haut" class="LargeurTotale">
                <div id="HautMenu">
                    <div id="Header">
                        <div id="HautDroite">
                            <div class="LargeurMax">
                                <div class="BlocLogo">
                                    <a href="/accueil.aspx">
											<img id="IMGLogoMenu" src="/images/default/logos_h70.jpg"
                                            border="0" />
											<!--<img id="IMGLogoMenu" src="/images/default/Logo_Octobre_Rose.png"
                                            border="0" />-->
										
                                    </a>
                                </div>
                                <h1>Hôpitaux de Sarreguemines</h1>								
								<div id="BlocRecherche">
									<div onkeypress="javascript:return WebForm_FireDefaultButton(event, &#39;ctl00_ValiderRecherche&#39;)" style="position: relative;float:left;width:100%;padding:0;">
	
									<input name="ctl00$inputGroup" id="ctl00_inputGroup" type="text" class="form-control" placeholder="Recherche" style="position: relative;float:right;display:inline-block;height:32px;" />
									<a id="ctl00_ValiderRecherche" href="javascript:__doPostBack(&#39;ctl00$ValiderRecherche&#39;,&#39;&#39;)" style="position: relative;float:right;display:inline-block;"><i class="fas fa-search SearchIcon"></i></a>							
										
										
									
</div>
								</div>
                                <a id="ctl00_HLUrgences" href="urgences/2/64">
                                <div class="Urgences" style="padding:10px;">
                                    <!--<img src="/images/default/urgences.png"
                                            border="0" />-->
											<!--<img class="fas fa-bell fa-2x">-->
											 <div style="color:#ffffff;    font-size: 16px;"> Urgences</div>
                                    
                                </div>
									</a>
                                <a id="ctl00_HLConsultationMedecin" href="Rendez-vous-en-ligne/2/30">
                                <div class="ConsultationMedecin">
                                    <i class="fas fa-user-md fa-3x"></i>
                                   <div style="color:#ffffff;   font-weight:bold; font-size: 17px;"> Prendre un <br>rendez-vous</div>
                                </div>
									</a>
                                


                        </div>
                            </div>
                        <div id="BandeauMenu">
                        <div class="LargeurMax">
                            <div id="BandeauMenuContenu">
								<div class="BlocTel">								
								<i class="fas fa-phone"></i><b>CHS</b>&nbsp;:&nbsp;03&nbsp;87&nbsp;27&nbsp;98&nbsp;00 
								-
								<b>R.&nbsp;PAX</b>&nbsp;:&nbsp;03&nbsp;87&nbsp;27&nbsp;33&nbsp;10
								-
								<b>ST&nbsp;JOSEPH</b>&nbsp;:&nbsp;03&nbsp;87&nbsp;98&nbsp;76&nbsp;00 
								</div>
                                <div id="Menu">
                                    
                                            <div id="Portail8" class="Portail" style="padding:0;" onmouseover='javascript:PortailOver(8);'
                                                onmouseout='javascript:PortailOut(8);'>
                                                <div class='PortailLien'>

                                                    <a id="ctl00_RepeaterPortail_ctl00_HLPortail" class="PortailLien" href="Offre-de-soins/2/68">Offre de soins
													<i class="fas fa-chevron-down"></i>
													</a>
                                                    <input type="hidden" name="ctl00$RepeaterPortail$ctl00$HFPortail" id="ctl00_RepeaterPortail_ctl00_HFPortail" value="8" />

                                                    <div id="CadreModule8" class='Cache'>
                                                        
                                                    </div>
                                                </div>
                                            </div>
                                        
                                            <div id="Portail2" class="Portail" style="padding:0;" onmouseover='javascript:PortailOver(2);'
                                                onmouseout='javascript:PortailOut(2);'>
                                                <div class='PortailLien'>

                                                    <a id="ctl00_RepeaterPortail_ctl01_HLPortail" class="PortailLien">Patient et entourage
													<i class="fas fa-chevron-down"></i>
													</a>
                                                    <input type="hidden" name="ctl00$RepeaterPortail$ctl01$HFPortail" id="ctl00_RepeaterPortail_ctl01_HFPortail" value="2" />

                                                    <div id="CadreModule2" class='Cache'>
                                                        
                                                                <div class='CadreModule'
                                                                    onmouseover='javascript:AfficheSousModule(75);'
                                                                    onmouseout='javascript:CacheSousModule(75);'>
                                                                    <div class="Module">
                                                                        <input type="hidden" name="ctl00$RepeaterPortail$ctl01$RptModule$ctl00$HFModule" id="ctl00_RepeaterPortail_ctl01_RptModule_ctl00_HFModule" value="75" />

                                                                        <a id="ctl00_RepeaterPortail_ctl01_RptModule_ctl00_HLModule" class="ModuleLien" href="/Consultations/3/75">Consultation</a>
                                                                    </div>
                                                                    <div id='CadreSousModule_75' class="CadreSousModule"
                                                                        style="display: none;">
                                                                        
                                                                    </div>
                                                                </div>
                                                            
                                                                <div class='CadreModule'
                                                                    onmouseover='javascript:AfficheSousModule(57);'
                                                                    onmouseout='javascript:CacheSousModule(57);'>
                                                                    <div class="Module">
                                                                        <input type="hidden" name="ctl00$RepeaterPortail$ctl01$RptModule$ctl01$HFModule" id="ctl00_RepeaterPortail_ctl01_RptModule_ctl01_HFModule" value="57" />

                                                                        <a id="ctl00_RepeaterPortail_ctl01_RptModule_ctl01_HLModule" class="ModuleLien" href="/Hospitalisation/3/57">Hospitalisation</a>
                                                                    </div>
                                                                    <div id='CadreSousModule_57' class="CadreSousModule"
                                                                        style="display: none;">
                                                                        
                                                                    </div>
                                                                </div>
                                                            
                                                                <div class='CadreModule'
                                                                    onmouseover='javascript:AfficheSousModule(77);'
                                                                    onmouseout='javascript:CacheSousModule(77);'>
                                                                    <div class="Module">
                                                                        <input type="hidden" name="ctl00$RepeaterPortail$ctl01$RptModule$ctl02$HFModule" id="ctl00_RepeaterPortail_ctl01_RptModule_ctl02_HFModule" value="77" />

                                                                        <a id="ctl00_RepeaterPortail_ctl01_RptModule_ctl02_HLModule" class="ModuleLien" href="/Visiter-un-proche/3/77">Rendre visite à un proche</a>
                                                                    </div>
                                                                    <div id='CadreSousModule_77' class="CadreSousModule"
                                                                        style="display: none;">
                                                                        
                                                                    </div>
                                                                </div>
                                                            
                                                                <div class='CadreModule'
                                                                    onmouseover='javascript:AfficheSousModule(37);'
                                                                    onmouseout='javascript:CacheSousModule(37);'>
                                                                    <div class="Module">
                                                                        <input type="hidden" name="ctl00$RepeaterPortail$ctl01$RptModule$ctl03$HFModule" id="ctl00_RepeaterPortail_ctl01_RptModule_ctl03_HFModule" value="37" />

                                                                        <a id="ctl00_RepeaterPortail_ctl01_RptModule_ctl03_HLModule" class="ModuleLien" href="/r%c3%a8glementation/2/37">REGLEMENTATION</a>
                                                                    </div>
                                                                    <div id='CadreSousModule_37' class="CadreSousModule"
                                                                        style="display: none;">
                                                                        
                                                                    </div>
                                                                </div>
                                                            
                                                                <div class='CadreModule'
                                                                    onmouseover='javascript:AfficheSousModule(38);'
                                                                    onmouseout='javascript:CacheSousModule(38);'>
                                                                    <div class="Module">
                                                                        <input type="hidden" name="ctl00$RepeaterPortail$ctl01$RptModule$ctl04$HFModule" id="ctl00_RepeaterPortail_ctl01_RptModule_ctl04_HFModule" value="38" />

                                                                        <a id="ctl00_RepeaterPortail_ctl01_RptModule_ctl04_HLModule" class="ModuleLien" href="/Satisfaction/3/38">Satisfaction</a>
                                                                    </div>
                                                                    <div id='CadreSousModule_38' class="CadreSousModule"
                                                                        style="display: none;">
                                                                        
                                                                    </div>
                                                                </div>
                                                            
                                                    </div>
                                                </div>
                                            </div>
                                        
                                            <div id="Portail7" class="Portail" style="padding:0;" onmouseover='javascript:PortailOver(7);'
                                                onmouseout='javascript:PortailOut(7);'>
                                                <div class='PortailLien'>

                                                    <a id="ctl00_RepeaterPortail_ctl02_HLPortail" class="PortailLien">Professionnels
													<i class="fas fa-chevron-down"></i>
													</a>
                                                    <input type="hidden" name="ctl00$RepeaterPortail$ctl02$HFPortail" id="ctl00_RepeaterPortail_ctl02_HFPortail" value="7" />

                                                    <div id="CadreModule7" class='Cache'>
                                                        
                                                                <div class='CadreModule'
                                                                    onmouseover='javascript:AfficheSousModule(89);'
                                                                    onmouseout='javascript:CacheSousModule(89);'>
                                                                    <div class="Module">
                                                                        <input type="hidden" name="ctl00$RepeaterPortail$ctl02$RptModule$ctl00$HFModule" id="ctl00_RepeaterPortail_ctl02_RptModule_ctl00_HFModule" value="89" />

                                                                        <a id="ctl00_RepeaterPortail_ctl02_RptModule_ctl00_HLModule" class="ModuleLien" href="/comite-ethique/2/89">Comité Ethique</a>
                                                                    </div>
                                                                    <div id='CadreSousModule_89' class="CadreSousModule"
                                                                        style="display: none;">
                                                                        
                                                                    </div>
                                                                </div>
                                                            
                                                                <div class='CadreModule'
                                                                    onmouseover='javascript:AfficheSousModule(95);'
                                                                    onmouseout='javascript:CacheSousModule(95);'>
                                                                    <div class="Module">
                                                                        <input type="hidden" name="ctl00$RepeaterPortail$ctl02$RptModule$ctl01$HFModule" id="ctl00_RepeaterPortail_ctl02_RptModule_ctl01_HFModule" value="95" />

                                                                        <a id="ctl00_RepeaterPortail_ctl02_RptModule_ctl01_HLModule" class="ModuleLien" href="/pepiniere-d-entreprise-e-sante-ccdl/3/95">Pépinière d'entreprise E-santé CCDL</a>
                                                                    </div>
                                                                    <div id='CadreSousModule_95' class="CadreSousModule"
                                                                        style="display: none;">
                                                                        
                                                                    </div>
                                                                </div>
                                                            
                                                                <div class='CadreModule'
                                                                    onmouseover='javascript:AfficheSousModule(31);'
                                                                    onmouseout='javascript:CacheSousModule(31);'>
                                                                    <div class="Module">
                                                                        <input type="hidden" name="ctl00$RepeaterPortail$ctl02$RptModule$ctl02$HFModule" id="ctl00_RepeaterPortail_ctl02_RptModule_ctl02_HFModule" value="31" />

                                                                        <a id="ctl00_RepeaterPortail_ctl02_RptModule_ctl02_HLModule" class="ModuleLien" href="/Professionnels-de-sante/3/31">Professionnels de santé</a>
                                                                    </div>
                                                                    <div id='CadreSousModule_31' class="CadreSousModule"
                                                                        style="display: none;">
                                                                        
                                                                    </div>
                                                                </div>
                                                            
                                                                <div class='CadreModule'
                                                                    onmouseover='javascript:AfficheSousModule(32);'
                                                                    onmouseout='javascript:CacheSousModule(32);'>
                                                                    <div class="Module">
                                                                        <input type="hidden" name="ctl00$RepeaterPortail$ctl02$RptModule$ctl03$HFModule" id="ctl00_RepeaterPortail_ctl02_RptModule_ctl03_HFModule" value="32" />

                                                                        <a id="ctl00_RepeaterPortail_ctl02_RptModule_ctl03_HLModule" class="ModuleLien" href="/Emploi/7/32">Offres d'emploi</a>
                                                                    </div>
                                                                    <div id='CadreSousModule_32' class="CadreSousModule"
                                                                        style="display: none;">
                                                                        
                                                                    </div>
                                                                </div>
                                                            
                                                                <div class='CadreModule'
                                                                    onmouseover='javascript:AfficheSousModule(88);'
                                                                    onmouseout='javascript:CacheSousModule(88);'>
                                                                    <div class="Module">
                                                                        <input type="hidden" name="ctl00$RepeaterPortail$ctl02$RptModule$ctl04$HFModule" id="ctl00_RepeaterPortail_ctl02_RptModule_ctl04_HFModule" value="88" />

                                                                        <a id="ctl00_RepeaterPortail_ctl02_RptModule_ctl04_HLModule" class="ModuleLien" href="/signalement-des-violences-et-du-harcelement/2/88">Signalement des violences et du harcèlement</a>
                                                                    </div>
                                                                    <div id='CadreSousModule_88' class="CadreSousModule"
                                                                        style="display: none;">
                                                                        
                                                                    </div>
                                                                </div>
                                                            
                                                                <div class='CadreModule'
                                                                    onmouseover='javascript:AfficheSousModule(34);'
                                                                    onmouseout='javascript:CacheSousModule(34);'>
                                                                    <div class="Module">
                                                                        <input type="hidden" name="ctl00$RepeaterPortail$ctl02$RptModule$ctl05$HFModule" id="ctl00_RepeaterPortail_ctl02_RptModule_ctl05_HFModule" value="34" />

                                                                        <a id="ctl00_RepeaterPortail_ctl02_RptModule_ctl05_HLModule" class="ModuleLien" href="/Fournisseurs/3/34">Achats, fournisseurs</a>
                                                                    </div>
                                                                    <div id='CadreSousModule_34' class="CadreSousModule"
                                                                        style="display: none;">
                                                                        
                                                                    </div>
                                                                </div>
                                                            
                                                    </div>
                                                </div>
                                            </div>
                                        
                                </div>
                            </div>
                        </div>
                        </div>
                    </div>
                </div>
                <div id="HautTrait">
                    <div id="LogoTrait">
                        <a href="/accueil.aspx">
                            <img id="IMGLogoTrait" src="/images/Default/logos_h70.jpg"
                                border="0" /></a>
                    </div>
						<div class="BlocTel">								
								<i class="fas fa-phone"></i><b>CHS</b>&nbsp;:&nbsp;03&nbsp;87&nbsp;27&nbsp;98&nbsp;00 
								-
								<b>R.&nbsp;PAX</b>&nbsp;:&nbsp;03&nbsp;87&nbsp;27&nbsp;33&nbsp;10
								-
								<b>ST&nbsp;JOSEPH</b>&nbsp;:&nbsp;03&nbsp;87&nbsp;98&nbsp;76&nbsp;00 
								</div>
                    <div id="MenuTrait">
                        <i class="fas fa-bars fa-2x" style="cursor: pointer;" onclick="javascript:AfficheCacheDiv('MenuPortable');"></i>
                    </div>
                </div>
                <div id="MenuPortable" class="Cache">
                    <div id="StructurePortable">
                        
                                <div class='SP_FondPortail'>
                                    <div class='SP_Portail' onclick='window.location.href="/Offre-de-soins/2/68";'>
                                        <div class='SP_PortailTitre'>
                                            <a id="ctl00_RptPortail_ctl00_LinkButton1" href="javascript:__doPostBack(&#39;ctl00$RptPortail$ctl00$LinkButton1&#39;,&#39;&#39;)">OFFRE DE SOINS</a>
                                        </div>
                                    </div>
                                    <div class='SP_Module1'>
                                        
                                        <div class="SP_EspaceModule">
                                        </div>
                                    </div>
                                </div>
                            
                                <div class='SP_FondPortail'>
                                    <div class='SP_Portail' onclick='window.location.href="/Prendre-rendez-vous/3/74";'>
                                        <div class='SP_PortailTitre'>
                                            <a id="ctl00_RptPortail_ctl01_LinkButton1" href="javascript:__doPostBack(&#39;ctl00$RptPortail$ctl01$LinkButton1&#39;,&#39;&#39;)">PATIENT ET ENTOURAGE</a>
                                        </div>
                                    </div>
                                    <div class='SP_Module1'>
                                        
                                                <div class='SP_Module1Texte' onclick='window.location.href="/Consultations/3/75";'>
                                                    <a id="ctl00_RptPortail_ctl01_RptModule1_ctl00_LinkButton2" href="javascript:__doPostBack(&#39;ctl00$RptPortail$ctl01$RptModule1$ctl00$LinkButton2&#39;,&#39;&#39;)">Consultation</a>
                                                </div>
                                                <div class='SP_Module2' style='display:none;'>
                                                    
                                                </div>
                                            
                                                <div class='SP_Module1Texte' onclick='window.location.href="/Hospitalisation/3/57";'>
                                                    <a id="ctl00_RptPortail_ctl01_RptModule1_ctl01_LinkButton2" href="javascript:__doPostBack(&#39;ctl00$RptPortail$ctl01$RptModule1$ctl01$LinkButton2&#39;,&#39;&#39;)">Hospitalisation</a>
                                                </div>
                                                <div class='SP_Module2' style='display:none;'>
                                                    
                                                </div>
                                            
                                                <div class='SP_Module1Texte' onclick='window.location.href="/Visiter-un-proche/3/77";'>
                                                    <a id="ctl00_RptPortail_ctl01_RptModule1_ctl02_LinkButton2" href="javascript:__doPostBack(&#39;ctl00$RptPortail$ctl01$RptModule1$ctl02$LinkButton2&#39;,&#39;&#39;)">Rendre visite à un proche</a>
                                                </div>
                                                <div class='SP_Module2' style='display:none;'>
                                                    
                                                </div>
                                            
                                                <div class='SP_Module1Texte' onclick='window.location.href="/règlementation/2/37";'>
                                                    <a id="ctl00_RptPortail_ctl01_RptModule1_ctl03_LinkButton2" href="javascript:__doPostBack(&#39;ctl00$RptPortail$ctl01$RptModule1$ctl03$LinkButton2&#39;,&#39;&#39;)">REGLEMENTATION</a>
                                                </div>
                                                <div class='SP_Module2' style='display:none;'>
                                                    
                                                </div>
                                            
                                                <div class='SP_Module1Texte' onclick='window.location.href="/Satisfaction/3/38";'>
                                                    <a id="ctl00_RptPortail_ctl01_RptModule1_ctl04_LinkButton2" href="javascript:__doPostBack(&#39;ctl00$RptPortail$ctl01$RptModule1$ctl04$LinkButton2&#39;,&#39;&#39;)">Satisfaction</a>
                                                </div>
                                                <div class='SP_Module2' style='display:none;'>
                                                    
                                                </div>
                                            
                                        <div class="SP_EspaceModule">
                                        </div>
                                    </div>
                                </div>
                            
                                <div class='SP_FondPortail'>
                                    <div class='SP_Portail' onclick='window.location.href="/Professionnels-de-sante/3/31";'>
                                        <div class='SP_PortailTitre'>
                                            <a id="ctl00_RptPortail_ctl02_LinkButton1" href="javascript:__doPostBack(&#39;ctl00$RptPortail$ctl02$LinkButton1&#39;,&#39;&#39;)">PROFESSIONNELS</a>
                                        </div>
                                    </div>
                                    <div class='SP_Module1'>
                                        
                                                <div class='SP_Module1Texte' onclick='window.location.href="/comite-ethique/2/89";'>
                                                    <a id="ctl00_RptPortail_ctl02_RptModule1_ctl00_LinkButton2" href="javascript:__doPostBack(&#39;ctl00$RptPortail$ctl02$RptModule1$ctl00$LinkButton2&#39;,&#39;&#39;)">Comité Ethique</a>
                                                </div>
                                                <div class='SP_Module2' style='display:none;'>
                                                    
                                                </div>
                                            
                                                <div class='SP_Module1Texte' onclick='window.location.href="/pepiniere-d-entreprise-e-sante-ccdl/3/95";'>
                                                    <a id="ctl00_RptPortail_ctl02_RptModule1_ctl01_LinkButton2" href="javascript:__doPostBack(&#39;ctl00$RptPortail$ctl02$RptModule1$ctl01$LinkButton2&#39;,&#39;&#39;)">Pépinière d'entreprise E-santé CCDL</a>
                                                </div>
                                                <div class='SP_Module2' style='display:none;'>
                                                    
                                                </div>
                                            
                                                <div class='SP_Module1Texte' onclick='window.location.href="/Professionnels-de-sante/3/31";'>
                                                    <a id="ctl00_RptPortail_ctl02_RptModule1_ctl02_LinkButton2" href="javascript:__doPostBack(&#39;ctl00$RptPortail$ctl02$RptModule1$ctl02$LinkButton2&#39;,&#39;&#39;)">Professionnels de santé</a>
                                                </div>
                                                <div class='SP_Module2' style='display:none;'>
                                                    
                                                </div>
                                            
                                                <div class='SP_Module1Texte' onclick='window.location.href="/Emploi/7/32";'>
                                                    <a id="ctl00_RptPortail_ctl02_RptModule1_ctl03_LinkButton2" href="javascript:__doPostBack(&#39;ctl00$RptPortail$ctl02$RptModule1$ctl03$LinkButton2&#39;,&#39;&#39;)">Offres d'emploi</a>
                                                </div>
                                                <div class='SP_Module2' style='display:none;'>
                                                    
                                                </div>
                                            
                                                <div class='SP_Module1Texte' onclick='window.location.href="/signalement-des-violences-et-du-harcelement/2/88";'>
                                                    <a id="ctl00_RptPortail_ctl02_RptModule1_ctl04_LinkButton2" href="javascript:__doPostBack(&#39;ctl00$RptPortail$ctl02$RptModule1$ctl04$LinkButton2&#39;,&#39;&#39;)">Signalement des violences et du harcèlement</a>
                                                </div>
                                                <div class='SP_Module2' style='display:none;'>
                                                    
                                                </div>
                                            
                                                <div class='SP_Module1Texte' onclick='window.location.href="/Fournisseurs/3/34";'>
                                                    <a id="ctl00_RptPortail_ctl02_RptModule1_ctl05_LinkButton2" href="javascript:__doPostBack(&#39;ctl00$RptPortail$ctl02$RptModule1$ctl05$LinkButton2&#39;,&#39;&#39;)">Achats, fournisseurs</a>
                                                </div>
                                                <div class='SP_Module2' style='display:none;'>
                                                    
                                                </div>
                                            
                                        <div class="SP_EspaceModule">
                                        </div>
                                    </div>
                                </div>
                            
                    </div>
                </div>
            </div>
            <div id="CentreImage" style='background: url(/Images/Accueil/Slideshow/bandeau_sarreguemines.jpg) no-repeat center center; -webkit-background-size: 100%; background-size: 100%;'>
            </div>
            <div id="BlocContenu">
                <div id="Outils" class="LargeurMax">
                    <div style="position: relative; width: auto; float: left;">
                        <div style="position: relative; float: left; width: auto; margin: 8px 6px 0 15px;">
                            <a href="/Accueil.aspx">
                                <img src='/images/Default/Maison.png' border="0" /></a>
                        </div>
                        <div style="position: relative; float: right; margin-top: 8px; margin-right: 6px;">
                            <a href="javascript:CallPrint()">
                                <img src="/images/Default/print.png" border="0"
                                    title="Imprimer le texte" />
                            </a>
                        </div>
                        <div style="position: relative; float: right; margin-top: 12px; margin-right: 10px;">
                            <input type="image" name="ctl00$IBAMoins" id="ctl00_IBAMoins" src="/images/Default/AMoins.png" style="border-width:0px;" />
                            <input type="image" name="ctl00$IBA" id="ctl00_IBA" src="/images/Default/A.png" style="border-width:0px;" />
                            <input type="image" name="ctl00$IBAPlus" id="ctl00_IBAPlus" src="/images/Default/APlus.png" style="border-width:0px;" />
                        </div>
                    </div>
                </div>
                <div id="BlocFilAriane" class="LargeurMax">
                    <div id="ctl00_PanFilDAriane">
	
                    
</div>
                </div>
                <div id="Contenu" class="row LargeurMax">
                    <div id="Gauche" class="col-xs-12">
                        
                        
                        

                        <div id="ctl00_PanOffresdeSoins">
	  
							<div class="LargeurMax">
								<!-- Image Map Generated by http://www.image-map.net/ -->
								<img src="/images/Default/OFFRE-DE-SOINS-2023-min.jpg" style="width:100%;margin:30px auto;" alt="" usemap="#image-map">
								<map name="image-map">
									<area alt="Offre de soin du Centre Hospitalier spécialisé de Sarreguemines" href=' /offres-de-soins/5/65 ' coords="1,1,451,612" shape="rect">
									<area alt="Offre de soin de l'Hôpital Robert-Pax" href=' /Offre-soins/5/55 ' coords="468,1,904,612" shape="rect">
									<area alt="Offre de soin de l'Hôpital St-Joseph" href=' /Offre-soins/5/55 ' coords="947,1,1399,612" shape="rect">
								</map>
								<!--<a id="ctl00_HLODS_CHS" href="/offres-de-soins/5/65">
								<div class="ODS_CHS col-md-6">
									<div class="PlanCHS">							
									</div>
									<div class="Logo">									
										<img src="/images/Default/Logo-CHS.png" />
									</div>
								</div> 
								</a>
								<a id="ctl00_HLODS_CH" href="/Offre-soins/5/55">
								<div class="ODS_CH col-md-6">							
									<div class="PlanCH">						
									</div>
									<div class="Logo">
										<img src="/images/Default/Logo-CH.png" />						
									</div>					
								</div>
								</a>-->
								
								<!--<img src="/images/Default/OFFRE-DE-SOINS-2020.jpg" style="width:100%;margin:30px auto;" alt="" usemap="#Map">
								<map name="Map">
									<area shape="poly" alt="CHS" coords="0,0, 796,0, 568,640, 0,640" href=' /offres-de-soins/5/65 '>
									<area shape="poly" alt="CH" coords="833,0, 1400,0, 1400,640, 605,640" href=' /Offre-soins/5/55 '>
								</map>-->
							</div>

							
						
</div>
                        <div id="ctl00_PanContentPlaceHolder1">
	
                            <div class="TitreModule" style="position: relative; width: 100%; float: left;">
                                <h1>
                                    <span id="ctl00_LabModule"></span></h1>
                            </div>
                            <!-- Contenu du module -->
                            

    <div class="LargeurTotale">
        <div class="LargeurMax">
        <div id="SliderAccueil">
            <div id="Slider">
                <ul class="rslides">
                    
                            <!--<li style="width: 100%; height: 100%; background: url('LinkToDB.SLI.Image') center; background-size: cover;"></li>-->
							
									<li style="width: 100%; height: 100%; background: url('/Ressources/SLI/CHS JUILLET 20212023103115333205.jpg') center; background-size: cover;"></li>
                        
                            <!--<li style="width: 100%; height: 100%; background: url('LinkToDB.SLI.Image') center; background-size: cover;"></li>-->
							
									<li style="width: 100%; height: 100%; background: url('/Ressources/SLI/CH MAI 20192023103115334334.jpg') center; background-size: cover;"></li>
                        
                            <!--<li style="width: 100%; height: 100%; background: url('LinkToDB.SLI.Image') center; background-size: cover;"></li>-->
							
									<li style="width: 100%; height: 100%; background: url('/Ressources/SLI/BITCHE JUILLET 20212023103115335447.jpg') center; background-size: cover;"></li>
                        
                </ul>
            </div>
        </div>
        </div>
    </div>
    <div class="LargeurTotale">
        <div class="LargeurMax">
            <div class="MenuEtablissements">
                
                        <a id="ctl00_ContentPlaceHolder1_RptPortailEtablissement_ctl00_HLPortailEtablissement" href="Presentation/2/60">
                            <div class="PortailEtablissement">
                                <span id="ctl00_ContentPlaceHolder1_RptPortailEtablissement_ctl00_LabPortailEtablissement">CHS</span><input type="hidden" name="ctl00$ContentPlaceHolder1$RptPortailEtablissement$ctl00$HFPortailEtablissement" id="ctl00_ContentPlaceHolder1_RptPortailEtablissement_ctl00_HFPortailEtablissement" value="3" />
                            </div>
                        </a>
                    
                        <a id="ctl00_ContentPlaceHolder1_RptPortailEtablissement_ctl01_HLPortailEtablissement" href="Direction/2/61">
                            <div class="PortailEtablissement">
                                <span id="ctl00_ContentPlaceHolder1_RptPortailEtablissement_ctl01_LabPortailEtablissement">CH</span><input type="hidden" name="ctl00$ContentPlaceHolder1$RptPortailEtablissement$ctl01$HFPortailEtablissement" id="ctl00_ContentPlaceHolder1_RptPortailEtablissement_ctl01_HFPortailEtablissement" value="4" />
                            </div>
                        </a>
                    
                        <a id="ctl00_ContentPlaceHolder1_RptPortailEtablissement_ctl02_HLPortailEtablissement" href="presentation/2/62">
                            <div class="PortailEtablissement">
                                <span id="ctl00_ContentPlaceHolder1_RptPortailEtablissement_ctl02_LabPortailEtablissement">GHT de Moselle-Est</span><input type="hidden" name="ctl00$ContentPlaceHolder1$RptPortailEtablissement$ctl02$HFPortailEtablissement" id="ctl00_ContentPlaceHolder1_RptPortailEtablissement_ctl02_HFPortailEtablissement" value="5" />
                            </div>
                        </a>
                    
                        <a id="ctl00_ContentPlaceHolder1_RptPortailEtablissement_ctl03_HLPortailEtablissement" href="presentation/2/63">
                            <div class="PortailEtablissement">
                                <span id="ctl00_ContentPlaceHolder1_RptPortailEtablissement_ctl03_LabPortailEtablissement">IFSI</span><input type="hidden" name="ctl00$ContentPlaceHolder1$RptPortailEtablissement$ctl03$HFPortailEtablissement" id="ctl00_ContentPlaceHolder1_RptPortailEtablissement_ctl03_HFPortailEtablissement" value="9" />
                            </div>
                        </a>
                    
            </div>

            


			
			<div class="TitreH1">
                <h1>Vous recherchez</h1>
            </div>

            <div class="Etablissement col-sm-12">
                <div class="row Modules col-sm-12">
                    
                            <div class="BlocModule col-xs-12 col-sm-6">
                            <div style="background: url('/images/accueil/RDV.jpg') center;background-size: cover;">
								<div class="over">
								</div>
									<a id="ctl00_ContentPlaceHolder1_RptModules_ctl00_HLModule" href="Rendez-vous-en-ligne/2/30"><input type="hidden" name="ctl00$ContentPlaceHolder1$RptModules$ctl00$HFModule" id="ctl00_ContentPlaceHolder1_RptModules_ctl00_HFModule" value="30" /><span id="ctl00_ContentPlaceHolder1_RptModules_ctl00_LabTitre" class="LabTitre">Prendre un rendez-vous</span><span id="ctl00_ContentPlaceHolder1_RptModules_ctl00_LabEnSavoirPlus" class="LabEnSavoirPlus">En savoir plus</span></a>
                            </div>
							</div>
                        
                            <div class="BlocModule col-xs-12 col-sm-6">
                            <div style="background: url('/images/accueil/frais_sante_sarreguemines.png') center;background-size: cover;">
								<div class="over">
								</div>
									<a id="ctl00_ContentPlaceHolder1_RptModules_ctl01_HLModule" href="Regler-soins/2/24"><input type="hidden" name="ctl00$ContentPlaceHolder1$RptModules$ctl01$HFModule" id="ctl00_ContentPlaceHolder1_RptModules_ctl01_HFModule" value="24" /><span id="ctl00_ContentPlaceHolder1_RptModules_ctl01_LabTitre" class="LabTitre">Payer les frais de santé</span><span id="ctl00_ContentPlaceHolder1_RptModules_ctl01_LabEnSavoirPlus" class="LabEnSavoirPlus">En savoir plus</span></a>
                            </div>
							</div>
                        
                            <div class="BlocModule col-xs-12 col-sm-6">
                            <div style="background: url('/images/accueil/radio.jpg') center;background-size: cover;">
								<div class="over">
								</div>
									<a id="ctl00_ContentPlaceHolder1_RptModules_ctl02_HLModule" href="https://imagerie.hopitaux-sarreguemines.fr/" target="_blank"><input type="hidden" name="ctl00$ContentPlaceHolder1$RptModules$ctl02$HFModule" id="ctl00_ContentPlaceHolder1_RptModules_ctl02_HFModule" value="22" /><span id="ctl00_ContentPlaceHolder1_RptModules_ctl02_LabTitre" class="LabTitre">Résultats d'examens radiologiques</span><span id="ctl00_ContentPlaceHolder1_RptModules_ctl02_LabEnSavoirPlus" class="LabEnSavoirPlus">En savoir plus</span></a>
                            </div>
							</div>
                        
                            <div class="BlocModule col-xs-12 col-sm-6">
                            <div style="background: url('/images/accueil/dossier_medical.jpg') center;background-size: cover;">
								<div class="over">
								</div>
									<a id="ctl00_ContentPlaceHolder1_RptModules_ctl03_HLModule" href="Demande-dossier-medical/2/23"><input type="hidden" name="ctl00$ContentPlaceHolder1$RptModules$ctl03$HFModule" id="ctl00_ContentPlaceHolder1_RptModules_ctl03_HFModule" value="23" /><span id="ctl00_ContentPlaceHolder1_RptModules_ctl03_LabTitre" class="LabTitre">Demande de dossier médical</span><span id="ctl00_ContentPlaceHolder1_RptModules_ctl03_LabEnSavoirPlus" class="LabEnSavoirPlus">En savoir plus</span></a>
                            </div>
							</div>
                        
                </div>
            </div>
			
            <div class="TitreH1">
                <h1>Toute l'actualité</h1>
            </div>
            <div class="BlocNews col-sm-12">
                
                            <div class="col-xs-6 col-sm-6 col-md-3">
                        <a id="ctl00_ContentPlaceHolder1_RptNews_ctl00_HLNews" href="portes-ouvertes-nouvel-ifsi-de-sarreguemines/1/1/118">
                                <div class="News">
                                    <input type="hidden" name="ctl00$ContentPlaceHolder1$RptNews$ctl00$HFNews" id="ctl00_ContentPlaceHolder1_RptNews_ctl00_HFNews" value="118" />
                                    <div class="Image">
                                        <img id="ctl00_ContentPlaceHolder1_RptNews_ctl00_INews" src="/Ressources/NEW/ACTU%20-PO%20IFSI%2017%20MAI%2025-01-01-012025051207365750.png" style="border-width:0px;" />
                                    </div>
                                    <div class="Texte">
                                        <span id="ctl00_ContentPlaceHolder1_RptNews_ctl00_LabDate" class="Date"> 12 mai 2025</span><span id="ctl00_ContentPlaceHolder1_RptNews_ctl00_LabTitre" class="Titre">PORTES OUVERTES NOUVEL IFSI DE SARREGUEMINES</span>
                                        <div class="BlocEnSavoirPlus">
                                            <span id="ctl00_ContentPlaceHolder1_RptNews_ctl00_Lab" class="EnSavoirPlus">Voir l'article</span>
                                            <i class="fas fa-chevron-right"></i>
                                        </div>
                                    </div>
                                </div>								
								</a>
                            </div>
                    
                            <div class="col-xs-6 col-sm-6 col-md-3">
                        <a id="ctl00_ContentPlaceHolder1_RptNews_ctl01_HLNews" href="journee-portes-ouvertes-had/1/1/117">
                                <div class="News">
                                    <input type="hidden" name="ctl00$ContentPlaceHolder1$RptNews$ctl01$HFNews" id="ctl00_ContentPlaceHolder1_RptNews_ctl01_HFNews" value="117" />
                                    <div class="Image">
                                        <img id="ctl00_ContentPlaceHolder1_RptNews_ctl01_INews" src="/Ressources/NEW/ACTU%20-%20SOIREE%20PO%20HAD%20230525-012025051309440264.png" style="border-width:0px;" />
                                    </div>
                                    <div class="Texte">
                                        <span id="ctl00_ContentPlaceHolder1_RptNews_ctl01_LabDate" class="Date"> 28 avril 2025</span><span id="ctl00_ContentPlaceHolder1_RptNews_ctl01_LabTitre" class="Titre">JOURNEE PORTES OUVERTES HAD</span>
                                        <div class="BlocEnSavoirPlus">
                                            <span id="ctl00_ContentPlaceHolder1_RptNews_ctl01_Lab" class="EnSavoirPlus">Voir l'article</span>
                                            <i class="fas fa-chevron-right"></i>
                                        </div>
                                    </div>
                                </div>								
								<div class='clearfix visible-sm'></div></a>
                            </div>
                    
                            <div class="col-xs-6 col-sm-6 col-md-3">
                        <a id="ctl00_ContentPlaceHolder1_RptNews_ctl02_HLNews" href="index-egalite-professionnelle/1/1/112">
                                <div class="News">
                                    <input type="hidden" name="ctl00$ContentPlaceHolder1$RptNews$ctl02$HFNews" id="ctl00_ContentPlaceHolder1_RptNews_ctl02_HFNews" value="112" />
                                    <div class="Image">
                                        <img id="ctl00_ContentPlaceHolder1_RptNews_ctl02_INews" src="/Ressources/NEW/INDEX%20EGALITE%20PROF-012024120515222077.png" style="border-width:0px;" />
                                    </div>
                                    <div class="Texte">
                                        <span id="ctl00_ContentPlaceHolder1_RptNews_ctl02_LabDate" class="Date"> 5 décembre 2024</span><span id="ctl00_ContentPlaceHolder1_RptNews_ctl02_LabTitre" class="Titre">Index égalité professionnelle</span>
                                        <div class="BlocEnSavoirPlus">
                                            <span id="ctl00_ContentPlaceHolder1_RptNews_ctl02_Lab" class="EnSavoirPlus">Voir l'article</span>
                                            <i class="fas fa-chevron-right"></i>
                                        </div>
                                    </div>
                                </div>								
								</a>
                            </div>
                    

                <div class="col-xs-6 col-sm-6 col-md-3">
					<div class="Facebook">
						<div>
							<span><i class="fab fa-facebook-square fa-3x"></i></span>
							<span>Suivez notre <br />actualité <br />sur facebook<br />
							</span>
							<a href="https://www.facebook.com/CH.sarreguemines/" class="CH">CH</a>
							<a href="#" class="CH">CHS</a>
						</div>
					</div>
				</div>
            </div>

            <div class="TitreH1">
                <h1>Focus</h1>
            </div>
            <div class="BlocNews BlocFocus col-sm-12">
				
                            <div class="col-xs-6 col-sm-6 col-md-3">
                        <a id="ctl00_ContentPlaceHolder1_RptFocus_ctl00_HLNews" href="don-d-organes-et-de-tissus/1/69/119">
                                <div class='News Bleu'>
                                    <input type="hidden" name="ctl00$ContentPlaceHolder1$RptFocus$ctl00$HFNews" id="ctl00_ContentPlaceHolder1_RptFocus_ctl00_HFNews" value="119" />
                                    <div class="Image">
                                        <img id="ctl00_ContentPlaceHolder1_RptFocus_ctl00_INews" src="/Ressources/NEW/FOCUS%20-%20%20DON%20ORGANES-012025061111571437.png" style="border-width:0px;" />
                                    </div>
                                    <div class="Texte">
                                        <span id="ctl00_ContentPlaceHolder1_RptFocus_ctl00_LabDate" class="Date"> 11 juin 2025</span><span id="ctl00_ContentPlaceHolder1_RptFocus_ctl00_LabTitre" class="Titre">DON D'ORGANES ET DE TISSUS</span>
                                        <div class="BlocEnSavoirPlus">
                                            <span id="ctl00_ContentPlaceHolder1_RptFocus_ctl00_Lab" class="EnSavoirPlus">Voir l'article</span>
                                            <i class="fas fa-chevron-right"></i>
                                        </div>
                                    </div>
                                </div>								
								</a>
                            </div>
                    
                            <div class="col-xs-6 col-sm-6 col-md-3">
                        <a id="ctl00_ContentPlaceHolder1_RptFocus_ctl01_HLNews" href="mars-bleu/1/69/115">
                                <div class='News Gris'>
                                    <input type="hidden" name="ctl00$ContentPlaceHolder1$RptFocus$ctl01$HFNews" id="ctl00_ContentPlaceHolder1_RptFocus_ctl01_HFNews" value="115" />
                                    <div class="Image">
                                        <img id="ctl00_ContentPlaceHolder1_RptFocus_ctl01_INews" src="/Ressources/NEW/FOCUS%20-%20%20MARS%20BLEU-012025030614043446.png" style="border-width:0px;" />
                                    </div>
                                    <div class="Texte">
                                        <span id="ctl00_ContentPlaceHolder1_RptFocus_ctl01_LabDate" class="Date"> 6 mars 2025</span><span id="ctl00_ContentPlaceHolder1_RptFocus_ctl01_LabTitre" class="Titre">MARS BLEU</span>
                                        <div class="BlocEnSavoirPlus">
                                            <span id="ctl00_ContentPlaceHolder1_RptFocus_ctl01_Lab" class="EnSavoirPlus">Voir l'article</span>
                                            <i class="fas fa-chevron-right"></i>
                                        </div>
                                    </div>
                                </div>								
								<div class='clearfix visible-sm'></div></a>
                            </div>
                    
                            <div class="col-xs-6 col-sm-6 col-md-3">
                        <a id="ctl00_ContentPlaceHolder1_RptFocus_ctl02_HLNews" href="Robot-d-assistance-chirurgical/1/69/109">
                                <div class='News Bleu'>
                                    <input type="hidden" name="ctl00$ContentPlaceHolder1$RptFocus$ctl02$HFNews" id="ctl00_ContentPlaceHolder1_RptFocus_ctl02_HFNews" value="109" />
                                    <div class="Image">
                                        <img id="ctl00_ContentPlaceHolder1_RptFocus_ctl02_INews" src="/Ressources/NEW/ACTU%20-%20robot-01-012024092310403215.png" style="border-width:0px;" />
                                    </div>
                                    <div class="Texte">
                                        <span id="ctl00_ContentPlaceHolder1_RptFocus_ctl02_LabDate" class="Date"> 23 septembre 2024</span><span id="ctl00_ContentPlaceHolder1_RptFocus_ctl02_LabTitre" class="Titre">Robot d'assistance chirurgical</span>
                                        <div class="BlocEnSavoirPlus">
                                            <span id="ctl00_ContentPlaceHolder1_RptFocus_ctl02_Lab" class="EnSavoirPlus">Voir l'article</span>
                                            <i class="fas fa-chevron-right"></i>
                                        </div>
                                    </div>
                                </div>								
								</a>
                            </div>
                    
                            <div class="col-xs-6 col-sm-6 col-md-3">
                        <a id="ctl00_ContentPlaceHolder1_RptFocus_ctl03_HLNews" href="urgences/1/69/93">
                                <div class='News Gris'>
                                    <input type="hidden" name="ctl00$ContentPlaceHolder1$RptFocus$ctl03$HFNews" id="ctl00_ContentPlaceHolder1_RptFocus_ctl03_HFNews" value="93" />
                                    <div class="Image">
                                        <img id="ctl00_ContentPlaceHolder1_RptFocus_ctl03_INews" src="/Ressources/NEW/FOCUS%20URGENCES-012024022310431471.png" style="border-width:0px;" />
                                    </div>
                                    <div class="Texte">
                                        <span id="ctl00_ContentPlaceHolder1_RptFocus_ctl03_LabDate" class="Date"> 23 février 2024</span><span id="ctl00_ContentPlaceHolder1_RptFocus_ctl03_LabTitre" class="Titre">Urgences</span>
                                        <div class="BlocEnSavoirPlus">
                                            <span id="ctl00_ContentPlaceHolder1_RptFocus_ctl03_Lab" class="EnSavoirPlus">Voir l'article</span>
                                            <i class="fas fa-chevron-right"></i>
                                        </div>
                                    </div>
                                </div>								
								<div class='clearfix visible-sm'></div></a>
                            </div>
                    
                <!---->
            </div>

			<iframe src="https://www.google.com/maps/d/u/0/embed?mid=1n5FxszS2Im8NJn_qf2JtvTOINZUfA53z" width="100%" height="480"></iframe>


        </div>
    </div>
    <div class="FooterAccueil LargeurTotale">
        <div class="LargeurMax">
            <div class="col-md-4">
                Centre Hospitalier Spécialisé<br />
                1, rue calmette<br />
                B.P. 80027<br />
                57212 SARREGUEMINES CEDEX<br />
                03 87 27 98 00
            </div>
            <div class="col-md-4">
                Hôpital R. Pax<br />
                2, rue René François Jolly<br />
                B.P. 50025<br />
                57211 SARREGUEMINES<br />
                03 87 27 33 10
            </div>
            <div class="col-md-4">
                Hôpital Saint Joseph<br />
                1, rue de Lebach<br />
                57230 BITCHE<br />
                03 87 98 76 00
            </div>
        </div>
    </div>
    <script>
            // For Demo purposes only (show hover effect on mobile devices)
            [].slice.call(document.querySelectorAll('a[href="#"')).forEach(function (el) {
                el.addEventListener('click', function (ev) { ev.preventDefault(); });
            });
    </script>

                        
</div>
                    </div>
                </div>				
				<div id="ctl00_FondGris" class="FondGris">
	
				
</div>
            </div>
            <div id="Footer">
                <div id="FooterContenu" class="row LargeurMax">
                    <a id="ctl00_HLFooter_5" href="DON/2/6">FAIRE UN DON</a>
                    <a id="ctl00_HLFooter_1" href="Contact/10/7">Nous contacter</a>
                    <a id="ctl00_HLFooter_2" href="actualites/1/1">Communication</a>
                    <a id="ctl00_HLFooter_3" href="Plan-site/16/17">Plan du site</a>
                    <a id="ctl00_HLFooter_4" href="Mentions-legales/2/18">Mentions légales</a>
                </div>
            </div>
			
			<!-- Pop up -->
			
        </div>
         <!-- Cookies -->   
        <div id="ctl00_PanCookies" class="cookie-box cookie-box--hide">
	
                En poursuivant votre navigation sur ce site, vous acceptez l'utilisation de cookies pour réaliser des statistiques de visite. 
                    <input type="submit" name="ctl00$BCoookieAccepter" value="Accepter" id="ctl00_BCoookieAccepter" class="cookie-button" />
                    <input type="submit" name="ctl00$BCoookieRefuser" value="Refuser" id="ctl00_BCoookieRefuser" class="cookie-button" />
                   
                    <!-- Lien vers la page Mentions légales ou Données personnelles
                       Une ancre peut être ajoutée pour arriver directement sur le paragraphe
                    -->
                    <a id="ctl00_HLCookiesEnSavoirPlus" class="cookie-button" href="/Mentions-legales/2/18#Cookies">En savoir plus</a>
        
</div>
        <script type="text/javascript">
            $(document).ready(function ($) {

                // delegate calls to data-toggle="lightbox"
                $(document).delegate('*[data-toggle="lightbox"]:not([data-gallery="navigateTo"])', 'click', function (event) {
                    event.preventDefault();
                    return $(this).ekkoLightbox({
                        onShown: function () {
                            if (window.console) {
                                return console.log('Checking our the events huh?');
                            }
                        },
                        onNavigate: function (direction, itemIndex) {
                            if (window.console) {
                                return console.log('Navigating ' + direction + '. Current item: ' + itemIndex);
                            }
                        }
                    });
                });

                //Programatically call
                $('#open-image').click(function (e) {
                    e.preventDefault();
                    $(this).ekkoLightbox();
                });
                $('#open-youtube').click(function (e) {
                    e.preventDefault();
                    $(this).ekkoLightbox();
                });

                $(document).delegate('*[data-gallery="navigateTo"]', 'click', function (event) {
                    event.preventDefault();
                    return $(this).ekkoLightbox({
                        onShown: function () {
                            var lb = this;
                            $(lb.modal_content).on('click', '.modal-footer a', function (e) {
                                e.preventDefault();
                                lb.navigateTo(2);
                            });
                        }
                    });
                });
            });
        </script>
        

        <!-- Responsive slider -->
        <script src="/Scripts/ResponsiveSlider/responsiveslides.js"></script>
        <script>
            $(function () {
                $(".rslides").responsiveSlides({
                    auto: true,             // Boolean: Animate automatically, true or false
                    speed: 1000,            // Integer: Speed of the transition, in milliseconds
                    timeout: 4000,          // Integer: Time between slide transitions, in milliseconds
                    pager: true,           // Boolean: Show pager, true or false
                    nav: false,             // Boolean: Show navigation, true or false
                    random: false,          // Boolean: Randomize the order of the slides, true or false
                    pause: false,           // Boolean: Pause on hover, true or false
                    pauseControls: true,    // Boolean: Pause when hovering controls, true or false
                    prevText: "Previous",   // String: Text for the "previous" button
                    nextText: "Next",       // String: Text for the "next" button
                    maxwidth: "",           // Integer: Max-width of the slideshow, in pixels
                    navContainer: "",       // Selector: Where controls should be appended to, default is after the 'ul'
                    manualControls: "",     // Selector: Declare custom pager navigation
                    namespace: "rslides",   // String: Change the default namespace used
                    before: function () { },   // Function: Before callback
                    after: function () { }     // Function: After callback
                });
            });
			

        </script>
		
		
	<script type="text/javascript" src="/Scripts/imageMapResponsive/jquery.rwdImageMaps.min.js"></script>
	<script type="text/javascript">

	$(document).ready(function(e) {
		$('img[usemap]').rwdImageMaps();
		
	});
	
	</script>
    

<script type="text/javascript">
//<![CDATA[
(function() {var fn = function() {$get("ctl00_ToolkitScriptManager1_HiddenField").value = '';Sys.Application.remove_init(fn);};Sys.Application.add_init(fn);})();
theForm.oldSubmit = theForm.submit;
theForm.submit = WebForm_SaveScrollPositionSubmit;

theForm.oldOnSubmit = theForm.onsubmit;
theForm.onsubmit = WebForm_SaveScrollPositionOnSubmit;
//]]>
</script>
</form>
</body>
</html>
